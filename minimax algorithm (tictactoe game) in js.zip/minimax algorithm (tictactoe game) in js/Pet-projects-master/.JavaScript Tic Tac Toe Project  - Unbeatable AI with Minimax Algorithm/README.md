JavaScript Tic Tac Toe Project  - Unbeatable AI w/ Minimax Algorithm (based on the freeCodeCamp tutorial: https://www.youtube.com/watch?v=P2TcQ3h0ipQ)

Codepen: https://codepen.io/ElaMoscicka/pen/WdRGPB  

![Screenshot](TicTacToe.PNG)

